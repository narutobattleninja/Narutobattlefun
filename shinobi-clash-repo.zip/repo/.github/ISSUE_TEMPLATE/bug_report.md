---
name: Bug report
about: Report something broken in Shinobi Clash
title: "[BUG] "
labels: bug
---

**Describe the bug**
A clear description of what's wrong.

**To Reproduce**
Steps to reproduce the behavior:
1. Go to '...'
2. Tap on '...'
3. See error

**Expected behavior**
What you expected to happen instead.

**Screenshots**
If applicable, add screenshots or a screen recording.

**Device (please complete the following information):**
- Device: [e.g. iPhone 14, Desktop]
- Browser: [e.g. Chrome, Safari]
- OS: [e.g. iOS 18, Windows 11]

**Additional context**
Anything else worth mentioning.
